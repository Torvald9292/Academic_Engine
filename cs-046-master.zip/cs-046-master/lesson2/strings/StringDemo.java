package strings;

public class StringDemo
{
    public static void main(String[] args)
    {
        String river = "Mississippi";
        int numberOfLetters = river.length();
        System.out.println(numberOfLetters);
    }
}