package ps5.blocksInLoop;

/**
 * Test the blockPrinter method
 */
public class DrawingPrinter
{
    public static void main(String[] args)
    {
        Drawings blocks = new Drawings();
        blocks.blockPrinter();
    }
}
