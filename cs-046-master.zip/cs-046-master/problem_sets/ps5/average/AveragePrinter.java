package ps5.average;

/**
 * Test the averageScore method
 */
public class AveragePrinter
{
    public static void main(String[] args)
    {
        MathUtil averager = new MathUtil();
        System.out.print(averager.averageScore());
    }
}