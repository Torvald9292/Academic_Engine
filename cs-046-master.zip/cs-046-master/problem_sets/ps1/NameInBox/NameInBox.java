package ps1.nameInBox;

// Write a program that will print the word Udacity in a box
// so that it looks exactly like the figure below. Name the program NameInBox

// +-------+
// |Udacity|
// +-------+ 
//


//HINT:
// Use System.out.println(...) to print:
// +
// |
// +
//
        

public class NameInBox
{
	public static void main(String[] args)
	{
        //TODO finish the draft so that your code prints Udacity in a box
		System.out.println("+-------+");
		System.out.println("|Udacity|");
		System.out.println("+-------+");
	}
}