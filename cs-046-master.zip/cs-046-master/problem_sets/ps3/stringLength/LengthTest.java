package ps3.stringLength;

/**
 * Complete the method to return the length of string parameter
 */
public class LengthTest
{
   /**
    * Gets the length of a string
    * @param str the string
    * @return the length of the string
    */
   public int stringLength(String str)
   {
       //your code goes here
	   return str.length();
   }
}