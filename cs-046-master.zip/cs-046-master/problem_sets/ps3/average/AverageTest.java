package ps3.average;

/**
 * Compelete the method to return the average of three numbers
 */
public class AverageTest
{
  public double average(int test1, int test2, int test3)
  {
      //you can put code here
	  double average = (test1 + test2 + test3) / 3.0;
	  return average;
  }
}