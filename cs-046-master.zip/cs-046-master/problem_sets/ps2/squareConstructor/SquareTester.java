package ps2.squareConstructor;

/**
 * A tester for the Square class
 * You don't need to change or modify this file   
 */
public class SquareTester
{
   public static void main(String[] args)
   {
       Square square = new Square(10.4);
       System.out.println(square.getSide());
       System.out.println("Expected: 10.4");
   }
}