package scene3;

//HIDE
public interface Drawable
{
    void draw();
}