package scene2;

public interface Drawable
{
    void draw();
}