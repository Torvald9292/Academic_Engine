package scene4;

//HIDE
public interface Drawable
{
    void draw();
}