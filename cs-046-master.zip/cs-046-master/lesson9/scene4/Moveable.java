package scene4;

public interface Moveable
{
    void move(int seconds);
}