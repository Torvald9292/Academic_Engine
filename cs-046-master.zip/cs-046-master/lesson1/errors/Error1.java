package errors;

public class Error1
{
    public static void main(String[] args)
    {
    	//compile-time error (syntax error):
        //System.ouch.println("Hello, World!");
    	System.out.println("Hello, World!");
    }
}
