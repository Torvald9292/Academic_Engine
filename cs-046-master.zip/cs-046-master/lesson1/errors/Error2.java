package errors;

public class Error2
{
    public static void main(String[] args)
    {
    	//run-time error (logic error):
        System.out.println("Hello, Word!");
    }
}
