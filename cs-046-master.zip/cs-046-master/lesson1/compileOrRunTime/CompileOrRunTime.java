package compileOrRunTime;

// TODO: Decide whether this is a compile-time or run-time error.

public class CompileOrRunTime
{
    public static void main(String[] args)
    {
    	//compile-time error:
        //System.out.println(Hello, Sarah);
    	//run-time error:
    	//System.out.println("Hello, Sarah");
    	System.out.println("Hello, Sara");
    }
}
