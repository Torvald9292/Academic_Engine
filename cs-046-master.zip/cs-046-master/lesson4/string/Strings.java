package string;

// BlueJ project: Tiles
// Video: Your turn to do it by hand


public class Strings
{
    public static void main(String[] args)
    {
    	String name = "Udacity";
    	
    	System.out.println(name.length());
    	System.out.println(name.substring(3, 7));
    	System.out.println(name.indexOf("c"));
    	System.out.println("Hello" + name);
    }
}