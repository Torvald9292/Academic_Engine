package mystery;

public class MysteryDouble
{
	public static void main(String[] args)
	{
		double oneMillion = 1000000;
		double mystery = oneMillion * oneMillion;
		System.out.println(mystery);
	}
}