package mystery;

public class ArithmeticOperations
{
	public static void main(String[] args)
	{
		int x = 3;
		int y = 4;
		int xy = 11;
		int cos = 5;
		
		double a = (x + 1 * 4) * (2 + y);
		double b = x + y / 2 + xy;
		double c = (4 + cos) / 2;
		
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
	}
}