package mystery;

public class Precision
{
	public static void main(String[] args)
	{
		double unitPrice = 4.35;
		double totalPrice = 100 * unitPrice;
		System.out.println(totalPrice);
	}
}