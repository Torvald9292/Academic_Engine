package mathFunctions;

public class MathFunctions
{
	public static void main(String[] args)
	{
		System.out.println(Math.pow(10, 3));
		System.out.println(Math.sqrt(4));
		System.out.println(Math.abs(3 - 5));
		System.out.println(Math.min(300, 255));
		System.out.println(Math.max(0, -1));
	}
}